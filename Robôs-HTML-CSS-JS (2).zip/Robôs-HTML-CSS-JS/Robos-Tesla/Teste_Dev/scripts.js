const prevButton = document.getElementById('prev');
const nextButton = document.getElementById('next');
const items = document.querySelectorAll('.item');
const dots = document.querySelectorAll('.dot');
const numberIndicator = document.querySelector('.numbers');
const form = document.getElementById('contactForm');
const successMessage = document.getElementById('successMessage');
const dateTimeBox = document.getElementById('datetime');

let active = 0;
const total = items.length;

function update(direction) {
    items[active].classList.remove('active');
    dots[active].classList.remove('active');
    active = direction > 0 ? (active + 1) % total : (active - 1 + total) % total;
    items[active].classList.add('active');
    dots[active].classList.add('active');
    numberIndicator.textContent = String(active + 1).padStart(2, '0');
}

prevButton.addEventListener('click', () => update(-1));
nextButton.addEventListener('click', () => update(1));

if (form) {
    form.addEventListener('submit', e => {
        e.preventDefault();
        const name = document.getElementById('name').value;
        successMessage.textContent = `Obrigado, ${name}! Sua mensagem foi registrada com sucesso.`;
        successMessage.style.display = 'block';
        form.reset();
    });
}

function updateDateTime() {
    if (dateTimeBox) {
        const now = new Date();
        dateTimeBox.textContent = now.toLocaleString('pt-BR', {
            dateStyle: 'full',
            timeStyle: 'medium'
        });
    }
}

setInterval(updateDateTime, 5000);
updateDateTime();
